<?php

namespace App\Controllers;

use App\Models\AlumnoModel;

class AlumnoController extends BaseController
{
    protected $alumnoModel;

    public function __construct()
    {
        $this->alumnoModel = new AlumnoModel();
    }

    public function index()
    {
        $data['alumnos'] = $this->alumnoModel->obtenerTipoConActividad();
        return view('alumnos/index', $data);
    }

    public function create()
    {
        $actividadModel = new \App\Models\TipoActividadModel();
        $data["actividades"] = $actividadModel->listarActividades();
        return view('alumnos/create', $data);
    }

    public function store()
    {
        // Verifica si los datos cumplen con las reglas de validación definidas en el modelo
        if ($this->validate($this->alumnoModel->getValidationRules())) {
            // Verifica si el DNI ya existe
            $existingAlumno = $this->alumnoModel->where('dni', $this->request->getPost('dni'))->first();

            if ($existingAlumno) {
                echo "<script>
            alert('El DNI ya ha sido registrado por otro alumno.');
            window.location.href='" . site_url('alumnos/create') . "';
            </script>";
                return;
            }

            $tipoActividad = $this->request->getPost('tipo_actividad');
            if ($tipoActividad == '0') {
                echo "<script>
                    alert('Por favor, seleccione un tipo de actividad válido.');
                    window.location.href='" . site_url('alumnos/create') . "';
                    </script>";
                return;
            }

            // Prepara los datos del alumno
            $data = [
                'nombre' => $this->request->getPost('nombre'),
                'apellido' => $this->request->getPost('apellido'),
                'dni' => $this->request->getPost('dni'),
                'telefono' => $this->request->getPost('telefono'),
                'direccion' => $this->request->getPost('direccion'),
                'nacimiento' => $this->request->getPost('nacimiento'),
                'correo' => $this->request->getPost('correo'),
                'fecha_registro' => $this->request->getPost('fecha_registro'),
                'tipo_actividad' => $this->request->getPost('tipo_actividad'),
                'observaciones' => $this->request->getPost('observacion'),
            ];

            // Guarda los datos del alumno
            if ($this->alumnoModel->save($data)) {
                echo "<script>
            alert('Se ha registrado exitosamente el alumno.');
            window.location.href='" . site_url('alumnos') . "';
            </script>";
                return;
            } else {
                echo "<script>
            alert('No se pudo crear el nuevo registro. Intente de nuevo.');
            window.location.href='" . site_url('alumnos/create') . "';
            </script>";
                return;
            }
        }

        // Si la validación falla, verifica campos obligatorios
        $validationErrors = $this->validator->getErrors();
        if (!empty($validationErrors)) {
            echo "<script>
        alert('Por favor, complete todos los campos requeridos. " . implode(' ', $validationErrors) . "');
        window.location.href='" . site_url('alumnos/create') . "';
        </script>";
            return;
        }
    }


    public function edit($id)
    {
        $model = new AlumnoModel();
        $actividadModel = new \App\Models\TipoActividadModel();

        $data['alumnos'] = $model->find($id);
        $data["actividades"] = $actividadModel->listarActividades();


        return view('alumnos/edit', $data);
    }

    public function update($id)
    {
        $model = new AlumnoModel();
        $actividadModel = new \App\Models\TipoActividadModel();

        // Definir las reglas de validación
        $rules = [
            'nombre' => 'required|min_length[3]|max_length[255]',
            'apellido' => 'required|min_length[3]|max_length[50]',
            'dni' => 'required|numeric',
            'telefono' => 'required|numeric',
            'correo' => "required|valid_email|is_unique[instructores.mail,id,{$id}]",
            'fecha_registro' => 'required|valid_date',
            'nacimiento' => 'required|valid_date',
            'tipo_actividad' => 'required',
            'direccion' => 'required|min_length[3]|max_length[255]',
            'observaciones' => 'permit_empty|min_length[3]|max_length[300]' // Observaciones permitidas vacías
        ];

        // Verificar si los datos cumplen con las reglas de validación
        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('error', 'Revisa los campos del formulario.');
        }

        // Recoger los datos del formulario
        $alumnoData = [
            'nombre' => $this->request->getPost('nombre'),
            'apellido' => $this->request->getPost('apellido'),
            'dni' => $this->request->getPost('dni'),
            'telefono' => $this->request->getPost('telefono'),
            'correo' => $this->request->getPost('correo'),
            'fecha_registro' => $this->request->getPost('fecha_registro'),
            'nacimiento' => $this->request->getPost('nacimiento'),
            'tipo_actividad' => $this->request->getPost('tipo_actividad'),
            'direccion' => $this->request->getPost('direccion'),
            'observaciones' => $this->request->getPost('observacion')
        ];

        // Debug: Verifica los datos recibidos
        log_message('debug', 'Datos recibidos para actualizar: ' . json_encode($alumnoData));

        // Verificar si el DNI ya está registrado en otro alumno
        $existingDNI = $model->where('dni', $this->request->getPost('dni'))->first();
        if ($existingDNI && $existingDNI['id'] !== $id) {
            return redirect()->to('/alumnos/edit/' . $id)
                ->with('error', 'El DNI ya está siendo utilizado por otro alumno.');
        }

        // Actualizar los datos del alumno
        if ($model->update($id, $alumnoData)) {
            echo "<script>
            alert('Alumno editado correctamente.');
            window.location.href='" . site_url('alumnos') . "';
        </script>";
            return;
        } else {
            echo "<script>
            alert('Hubo un problema al guardar los datos. Intente de nuevo.');
            window.location.href='" . site_url('alumnos/edit/' . $id) . "';
        </script>";
            return;
        }
    }


    public function delete($id)
    {
        $model = new AlumnoModel();
        $model->delete($id);

        return redirect()->to('/alumnos');
    }
}
