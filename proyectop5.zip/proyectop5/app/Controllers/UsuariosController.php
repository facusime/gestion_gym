<?php

namespace App\Controllers;

use App\Models\UsuarioModel;

class UsuariosController extends BaseController
{
    public function index()
    {
        $model = new UsuarioModel();
        $data['usuarios'] = $model->findAll();

        return view('usuarios/index', $data);
    }

    public function create()
    {
        return view('usuarios/create');
    }

    public function store()
    {
        $model = new UsuarioModel();

        $usuario = $this->request->getPost('usuario');


        $existingUser = $model->where('usuario', $usuario)->first();
        if ($existingUser) {
            echo "<script>
            alert('Este usuario ya está registrado.');
            window.location.href='" . site_url('usuarios/create') . "';
        </script>";
            return;
        }

        $data = [
            'nombre' => $this->request->getPost('nombre'),
            'apellido' => $this->request->getPost('apellido'),
            'usuario' => $this->request->getPost('usuario'),
            'pass' => $this->request->getPost('pass'),
        ];

        if ($model->insert($data)) {
            echo "<script>
                alert('Usuario creada correctamente.');
                window.location.href='" . site_url('usuarios') . "';
            </script>";
            return;
        } else {
            echo "<script>
                alert('Hubo un problema al guardar los datos. Intente de nuevo.');
                window.location.href='" . site_url('usuarios/create') . "';
            </script>";
            return;
        }

        return redirect()->to('/usuarios'); // Ajuste aquí
    }

    public function edit($id)
    {
        $model = new UsuarioModel();
        $data['usuario'] = $model->find($id);

        return view('usuarios/edit', $data);
    }

    public function update($id)
    {
        $model = new UsuarioModel();

        // Obtener los datos del formulario
        $usuario = $this->request->getPost('usuario');

        // Verificar si el usuario ya existe y no es el mismo que se está actualizando
        $existingUser = $model->where('usuario', $usuario)->where('id !=', $id)->first();
        if ($existingUser) {
            echo "<script>
                alert('Este usuario ya está registrado.');
                window.location.href='" . site_url('usuarios/edit/' . $id) . "';
            </script>";
            return;
        }

        // Preparar los datos del usuario
        $data = [
            'nombre' => $this->request->getPost('nombre'),
            'apellido' => $this->request->getPost('apellido'),
            'usuario' => $usuario,
            'pass' => $this->request->getPost('pass'),
        ];

        // Intentar actualizar el usuario
        if ($model->update($id, $data)) {
            echo "<script>
                alert('Usuario editado correctamente.');
                window.location.href='" . site_url('usuarios') . "';
            </script>";
            return;
        } else {
            echo "<script>
                alert('Hubo un problema al guardar los datos. Intente de nuevo.');
                window.location.href='" . site_url('usuarios/edit/' . $id) . "';
            </script>";
            return;
        }
    }


    public function delete($id)
    {
        $model = new UsuarioModel();
        $model->delete($id);

        return redirect()->to('/usuarios'); // Ajuste aquí
    }
}
