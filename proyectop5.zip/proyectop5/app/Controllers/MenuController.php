<?php

namespace App\Controllers;


class MenuController extends BaseController
{
    public function index(): string
    {
        return view('menu');
    }
}
