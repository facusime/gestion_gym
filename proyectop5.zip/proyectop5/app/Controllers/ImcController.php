<?php

namespace App\Controllers;

use App\Models\AlumnoModel;
use App\Models\ImcModel;

class ImcController extends BaseController
{
    public function index()
    {
        $model = new ImcModel();
        $data['imc'] = $model->obtenerAlumnos(); // Ajuste aquí

        return view('imc/index', $data);
    }

    public function create()
    {
        $alumnoModel = new AlumnoModel();
        $data["alumnos"] = $alumnoModel->findAll(); // Ajuste aquí

        return view('imc/create', $data);
    }

    public function store()
    {
        $model = new ImcModel();

        date_default_timezone_set("America/Argentina/San_Juan");
        $fechaActual = date("Y-m-d");

        $alumno = $this->request->getPost('alumno');
        $peso = $this->request->getPost('peso');
        $altura = $this->request->getPost('altura');

        // Verificar si ya existe un registro para el alumno
        $done = $model->where('alumno', $alumno)->first();
        if ($done) {
            echo "<script>
        alert('Este alumno ya tiene un registro de IMC. Edite los valores del mismo para actualizarlo.');
        window.location.href='" . site_url('imc/create') . "';
        </script>";
            return;
        }

        // Validar que la altura sea un número decimal
        if (!is_numeric($altura) || strpos($altura, '.') === false) {
            echo "<script>
        alert('Por favor, ingresa una altura válida en formato decimal.');
        window.location.href='" . site_url('imc/create') . "';
        </script>";
            return;
        }

        $calculo = $peso / ($altura * $altura); // Cálculo del IMC

        $data = [
            'alumno' => $alumno,
            'peso' => $peso,
            'altura' => $altura,
            'calculo' => $calculo,
            'fecha_calculo' => $fechaActual,
            'fecha_modificacion' => null, // Inicialmente nulo
        ];

        // Guarda los datos del alumno
        if ($model->save($data)) {
            echo "<script>
        alert('Se ha registrado exitosamente el IMC del alumno.');
        window.location.href='" . site_url('imc') . "';
        </script>";
            return;
        } else {
            echo "<script>
        alert('No se pudo crear el nuevo registro. Intente de nuevo.');
        window.location.href='" . site_url('imc/create') . "';
        </script>";
            return;
        }
    }



    public function edit($id)
    {
        $imcModel = new ImcModel();
        $alumnoModel = new AlumnoModel();

        // Obtener los datos del IMC que se va a editar
        $data['imc'] = $imcModel->find($id);

        // Obtener la lista de alumnos para el dropdown
        $data['alumnos'] = $alumnoModel->findAll();

        return view('imc/edit', $data);
    }


    public function update($id)
    {
        $imcModel = new ImcModel();

        date_default_timezone_set("America/Argentina/San_Juan");
        $fechaActual = date("Y-m-d");

        // Obtener el registro existente para mantener la fecha_calculo
        $existingData = $imcModel->find($id);

        $peso = $this->request->getPost('peso');
        $altura = $this->request->getPost('altura');
        $calculo = $peso / ($altura * $altura); // Cálculo del IMC

        $data = [
            'alumno' => $this->request->getPost('alumno'),
            'peso' => $peso,
            'altura' => $altura,
            'calculo' => $calculo,
            // Mantener la fecha_calculo original
            'fecha_calculo' => $existingData['fecha_calculo'],
            'fecha_modificacion' => $fechaActual, // Actualizar la fecha de modificación
        ];

        if ($imcModel->update($id, $data)) {
            echo "<script>
                alert('IMC actualizado correctamente.');
                window.location.href='" . site_url('imc') . "';
            </script>";
            return;
        } else {
            echo "<script>
                alert('Hubo un problema al guardar los datos. Intente de nuevo.');
                window.location.href='" . site_url('imc/edit/' . $id) . "';
            </script>";
            return;
        };

        return redirect()->to('/imc');
    }


    public function delete($id)
    {
        $model = new ImcModel();
        $model->delete($id);

        return redirect()->to('/imc');
    }
}
