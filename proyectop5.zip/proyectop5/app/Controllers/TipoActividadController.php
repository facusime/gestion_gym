<?php

namespace App\Controllers;

use App\Models\TipoActividadModel;

class TipoActividadController extends BaseController
{
    public function index()
    {
        $model = new TipoActividadModel();
        $data['actividades'] = $model->findAll();
        return view('tipo_actividad/index', $data);
    }

    public function create()
    {
        return view('tipo_actividad/create');
    }

    public function store()
    {
        $model = new TipoActividadModel();

        $data = [
            'nombre' => $this->request->getVar('nombre'),
            'descripcion' => $this->request->getVar('descripcion')
        ];

        if ($model->save($data)) {
            echo "<script>
                alert('Se ha registrado exitosamente la actividad.');
                window.location.href='" . site_url('tipo_actividad') . "';
            </script>";
        } else {
            echo "<script>
                alert('No se pudo crear el nuevo registro. Intente de nuevo.');
                window.location.href='" . site_url('tipo_actividad/create') . "';
            </script>";
        }
    }


    public function edit($id)
    {
        $model = new TipoActividadModel();
        $data['actividad'] = $model->find($id);

        return view('tipo_actividad/edit', $data);
    }

    public function update($id)
    {
        $model = new TipoActividadModel();

        $data = [
            'nombre' => $this->request->getVar('nombre'),
            'descripcion' => $this->request->getVar('descripcion')
        ];

        $existingNombre = $model->where('nombre', $data['nombre'])
            ->where('id !=', $id)
            ->first();

        if ($existingNombre) {
            return redirect()->to('/tipo_actividad/edit/' . $id)
                ->with('error', 'El nombre ya está siendo utilizado por otra actividad.');
        }
        if ($model->update($id, $data)) {
            return redirect()->to('/tipo_actividad')->with('success', 'Actividad actualizada exitosamente.');
        } else {
            $data['errors'] = $model->errors();
            return redirect()->to('/tipo_actividad')->with('error', 'No se pudo actualizar la actividad, verifique sus datos.')
                ->with('validation', $data['errors']);
        }
    }

    public function delete($id)
    {
        $model = new TipoActividadModel();
        $model->delete($id);

        return redirect()->to('/tipo_actividad')->with('success', 'Actividad eliminada exitosamente.');
    }
}
