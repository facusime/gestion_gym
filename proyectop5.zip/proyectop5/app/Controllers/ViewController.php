<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class ViewController extends Controller
{
    public function view($fileName)
    {
        $filePath = WRITEPATH . 'uploads/' . $fileName;

        if (file_exists($filePath)) {
            $extension = pathinfo($fileName, PATHINFO_EXTENSION);

            switch ($extension) {
                case 'pdf':
                    header('Content-Type: application/pdf');
                    break;
                case 'doc':
                case 'docx':
                    header('Content-Type: application/msword');
                    break;
                default:
                    header('Content-Type: application/octet-stream');
                    break;
            }

            readfile($filePath);
            exit;
        }

        // Mensaje de depuración
        echo "Archivo no encontrado: " . $filePath;
        return redirect()->back()->with('error', 'Archivo no encontrado');
    }
}
