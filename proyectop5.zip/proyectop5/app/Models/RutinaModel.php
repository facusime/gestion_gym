<?php

namespace App\Models;

use CodeIgniter\Model;

class RutinaModel extends Model
{
    protected $table = 'rutinas';
    protected $primaryKey = 'id';
    protected $allowedFields = ['alumno', 'tipo_actividad', 'titulo', 'descripcion', 'archivo'];

    // Para obtener las rutinas personalizadas (que tienen asignado un alumno)
    public function obtenerRutinasPersonalizadas()
    {
        return $this->select('rutinas.*, alumnos.nombre as alumno_nombre, alumnos.apellido as alumno_apellido, tipo_actividad.nombre as actividad_nombre')
            ->join('alumnos', 'alumnos.id = rutinas.alumno', 'left')
            ->join('tipo_actividad', 'tipo_actividad.id = rutinas.tipo_actividad')
            ->where('alumno IS NOT NULL') // Solo rutinas con alumnos
            ->findAll();
    }

    // Para obtener las rutinas genéricas (sin alumno asignado)
    public function obtenerRutinasGenericas()
    {
        return $this->select('rutinas.*, tipo_actividad.nombre as actividad_nombre')
            ->join('tipo_actividad', 'tipo_actividad.id = rutinas.tipo_actividad')
            ->where('alumno IS NULL') // Solo rutinas sin alumnos
            ->findAll();
    }
}
