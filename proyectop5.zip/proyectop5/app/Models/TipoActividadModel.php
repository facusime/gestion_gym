<?php

namespace App\Models;

use CodeIgniter\Model;

class TipoActividadModel extends Model
{
    protected $table = 'tipo_actividad';

    public function listarActividades()
    {
        return $this->findAll();
       } 
    protected $primaryKey = 'id';
    protected $allowedFields = ['nombre', 'descripcion'];
    protected $validationRules = [
        'nombre' => 'required|is_unique[tipo_actividad.nombre]', 
        'descripcion' => 'required'
    ];

    protected $validationMessages = [
        'nombre' => [
            'required' => 'El nombre de la actividad es obligatorio.',
            'is_unique' => 'El nombre de la actividad ya existe.'
        ],
        'descripcion' => [
            'required' => 'La descripción de la actividad es obligatoria.'
        ]
    ];
}
