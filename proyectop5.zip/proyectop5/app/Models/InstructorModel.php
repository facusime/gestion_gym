<?php

namespace App\Models;

use CodeIgniter\Model;

class InstructorModel extends Model
{
    protected $table      = 'instructores';
    protected $primaryKey = 'id';
    protected $allowedFields = ['nombre', 'apellido', 'rutina', 'telefono', 'mail'];

    protected $validationRules = [
        'nombre' => 'required|min_length[3]|max_length[50]',
        'apellido' => 'required|min_length[3]|max_length[50]',
        'telefono' => 'required|numeric',
        'mail' => 'required|valid_email', 
        'rutina' => 'required|is_not_unique[rutinas.id]'
    ];

    public $validationMessages = [
        'telefono' => [
            'required' => 'El número de teléfono es obligatorio.',
            'numeric'  => 'Por favor, ingrese solo números.',
        ],
        'mail' => [
            'required'   => 'El correo electrónico es obligatorio.',
            'valid_email'=> 'Por favor, ingrese un correo electrónico válido.',
        ],
    ];
}

