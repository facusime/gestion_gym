<?php

namespace App\Models;

use CodeIgniter\Model;

class UsuarioModel extends Model
{
    protected $table = 'usuarios'; // Nombre de la tabla en la base de datos
    protected $primaryKey = 'id'; // Clave primaria

    // Campos que se pueden insertar o actualizar en la base de datos
    protected $allowedFields = ['nombre', 'apellido', 'usuario', 'pass'];

    // Definir reglas de validación si es necesario
    protected $validationRules = [
        'usuario' => 'required|min_length[3]|max_length[50]',
        'pass' => 'required|min_length[3]|max_length[255]',
    ];

    /**
     * Busca un usuario por su nombre de usuario.
     * 
     * @param string $usuario
     * @return array|null
     */
    public function buscarPorUsuario($usuario)
    {
        return $this->where('usuario', $usuario)->first();
    }
}
