<?php

namespace App\Models;

use CodeIgniter\Model;

class TurnoModel extends Model
{
    protected $table = 'turnos'; // Nombre de la tabla
    protected $primaryKey = 'id'; // Clave primaria

    protected $allowedFields = ['tipo_actividad', 'instructor', 'horario']; // Campos permitidos para insertar/actualizar

    // Reglas de validación
    protected $validationRules = [
        'tipo_actividad' => 'required|integer',
        'instructor' => 'required|integer',
        'horario' => 'required|string|max_length[255]',
    ];

    protected $validationMessages = [
        'tipo_actividad' => [
            'required' => 'El campo Tipo de Actividad es obligatorio.',
            'integer' => 'El campo Tipo de Actividad debe ser un número entero.',
        ],
        'instructor' => [
            'required' => 'El campo Instructor es obligatorio.',
            'integer' => 'El campo Instructor debe ser un número entero.',
        ],
        'horario' => [
            'required' => 'El campo Horario es obligatorio.',
            'string' => 'El campo Horario debe ser una cadena de texto.',
            'max_length' => 'El campo Horario no puede exceder los 255 caracteres.',
        ],
    ];

    // Relacionar `tipo_actividad` y `instructor`
    public function getTurnos()
    {
        return $this->select('turnos.*, tipo_actividad.nombre as tipo_actividad_nombre, instructores.nombre as instructor_nombre, instructores.apellido as instructor_apellido')
                    ->join('tipo_actividad', 'tipo_actividad.id = turnos.tipo_actividad')
                    ->join('instructores', 'instructores.id = turnos.instructor')
                    ->findAll();
    }
}
