<?php

namespace App\Models;

use CodeIgniter\Model;

class AlumnoModel extends Model
{
    protected $table = 'alumnos';
    protected $primaryKey = 'id';

    public function listarAlumnos()
    {
        return $this->findAll();
    }

    protected $allowedFields = ['nombre', 'apellido', 'dni', 'correo', 'telefono', 'direccion', 'nacimiento', 'fecha_registro', 'tipo_actividad', 'observaciones'];
    protected $validationRules = [
        'nombre' => 'required',
        'apellido' => 'required',
        'dni' => 'required|numeric',
        'correo' => 'required|valid_email',
        'fecha_registro' => 'required|date',
        'tipo_actividad' => 'required|numeric',
        'telefono' => 'required|numeric',
        'direccion' => 'required',
        'nacimiento' => 'required|date',
        'observaciones' => 'permit_empty'

    ];
    public function obtenerTipoConActividad()
    {
        return $this->select('alumnos.*, tipo_actividad.nombre as actividad_nombre')
            ->join('tipo_actividad', 'tipo_actividad.id = alumnos.tipo_actividad')
            ->orderBy('alumnos.id', 'DESC') // Ordena por el ID en orden descendente
            ->findAll();
    }
}
