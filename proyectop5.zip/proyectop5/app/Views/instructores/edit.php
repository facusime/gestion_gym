<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Instructor</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="<?= base_url('/public/css/menu.css') ?>">
</head>

<body>
    <div class="container mt-5 d-flex justify-content-center">
        <div class="card p-4" style="background-color: #343a40;">
            <h1 class="text-center mb-4 text-white">Editar Instructor</h1>

            <?php if (isset($validation)): ?>
                <div class="alert alert-danger">
                    <?= $validation->listErrors() ?>
                </div>
            <?php endif; ?>

            <form action="<?= site_url('instructores/update/' . $instructor['id']) ?>" method="POST" class="d-flex flex-column align-items-center">
                <?= csrf_field() ?>

                <div class="mb-3 w-100">
                    <label for="nombre" class="form-label text-white">Nombre</label>
                    <input type="text" name="nombre" id="nombre" class="form-control" value="<?= esc($instructor['nombre']) ?>" required>
                </div>

                <div class="mb-3 w-100">
                    <label for="apellido" class="form-label text-white">Apellido</label>
                    <input type="text" name="apellido" id="apellido" class="form-control" value="<?= esc($instructor['apellido']) ?>" required>
                </div>

                <div class="mb-3 w-100">
                    <label for="telefono" class="form-label text-white">Teléfono</label>
                    <input type="tel" name="telefono" id="telefono" class="form-control" value="<?= esc($instructor['telefono']) ?>" required pattern="[0-9]*" title="Por favor, ingrese solo números.">
                </div>

                <div class="mb-3 w-100">
                    <label for="mail" class="form-label text-white">Mail</label>
                    <input type="email" name="mail" id="mail" class="form-control" value="<?= esc($instructor['mail']) ?>" required>
                </div>

                <div class="mb-3 w-100">
                    <label for="rutina" class="form-label text-white">Rutina</label>
                    <select name="rutina" id="rutina" class="form-select" required>
                        <option value="0">Elija Rutina</option>
                        <?php foreach ($rutinas as $rutina): ?>
                            <option value="<?= esc($rutina['id']) ?>" <?= (old('rutina', $instructor['rutina']) == $rutina['id']) ? 'selected' : '' ?>>
                                <?= esc($rutina['titulo']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="d-flex justify-content-between w-100">
                    <button type="submit" class="btn btn-primary">Guardar cambios</button>
                    <a href="<?= site_url('instructores') ?>" class="btn btn-secondary">Cancelar</a>
                </div>
            </form>
        </div>
    </div>

    <footer style="background-color: black; color: white; font-weight: bold; text-align: center;" class="mt-5">
        Desarrollado por Facundo Simeoni y Federico Moran.
    </footer>
</body>

</html>