<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Actividad</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="<?= base_url('/public/css/menu.css') ?>">
</head>

<body>
    <div class="container mt-5 d-flex justify-content-center">
        <div class="card p-4" style="max-width: 400px; background-color: #343a40;">
            <h1 class="text-center mb-4 text-white">Agregar Actividad</h1>

            <?php if (session()->getFlashdata('error')): ?>
                <div class="alert alert-danger">
                    <?= session()->getFlashdata('error') ?>
                </div>
            <?php endif; ?>

            <form action="<?= site_url('tipo_actividad/store') ?>" method="post" class="d-flex flex-column align-items-center">
                <?= csrf_field() ?>

                <div class="mb-3 w-100">
                    <label for="nombre" class="form-label text-white">Nombre</label>
                    <input type="text" class="form-control" id="nombre" name="nombre" value="<?= old('nombre') ?>" required>
                </div>

                <div class="mb-3 w-100">
                    <label for="descripcion" class="form-label text-white">Descripción</label>
                    <textarea class="form-control" id="descripcion" name="descripcion" required><?= old('descripcion') ?></textarea>
                </div>

                <div class="d-flex justify-content-between flex-wrap w-100">
                    <button type="submit" class="btn btn-primary btn-sm">Guardar</button>
                    <a href="<?= site_url('tipo_actividad') ?>" class="btn btn-secondary btn-sm">Cancelar</a>
                </div>
            </form>
        </div>
    </div>

    <footer style="background-color: black; color: white; font-weight: bold; text-align: center; padding: 10px;" class="mt-5">
        Desarrollado por Facundo Simeoni y Federico Moran.
    </footer>
</body>

</html>