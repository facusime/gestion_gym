<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Actividad</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <!-- Js Bootstrap-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <!-- Estilos propios-->
    <link rel="stylesheet" href="<?= base_url('/public/css/menu.css') ?>">
</head>

<body>
    <div class="container mt-5 d-flex justify-content-center">
        <div class="card p-4" style="width: 400px; background-color: #343a40;">
            <h1 class="text-center mb-4 text-white">Editar Actividad</h1>

            <?php if (session()->getFlashdata('error')): ?>
                <div class="alert alert-danger">
                    <?= session()->getFlashdata('error') ?>
                </div>
            <?php endif; ?>

            <form action="<?= site_url('tipo_actividad/update/' . $actividad['id']) ?>" method="post" class="d-flex flex-column align-items-center">
                <div class="mb-3 w-100">
                    <label for="nombre" class="form-label text-white">Nombre</label>
                    <input type="text" class="form-control" id="nombre" name="nombre" value="<?= esc($actividad['nombre']) ?>" required>
                </div>
                <div class="mb-3 w-100">
                    <label for="descripcion" class="form-label text-white">Descripción</label>
                    <textarea class="form-control" id="descripcion" name="descripcion" required><?= esc($actividad['descripcion']) ?></textarea>
                </div>
                <div class="d-flex justify-content-between w-100">
                    <button type="submit" class="btn btn-primary">Guardar cambios</button>
                    <a href="<?= site_url('tipo_actividad') ?>" class="btn btn-secondary">Cancelar</a>
                </div>
            </form>
        </div>
    </div>
    <br> <br> <br> <br> <br>
    <footer style="background-color: black; color: white; font-weight: bold; text-align: center;">
        Desarrollado por Facundo Simeoni y Federico Moran.
    </footer>
    <br>
</body>

</html>