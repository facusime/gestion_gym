<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar IMC</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <!-- Js Bootstrap-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <!-- Estilos propios-->
    <link rel="stylesheet" href="<?= base_url('/public/css/menu.css') ?>">
</head>

<body>
    <a href="<?= site_url('imc') ?>" class="btn btn-secondary mb-3">Volver al Menú</a>
    <div class="container mt-5 d-flex justify-content-center">
        <div class="card p-4" style="width: 400px; background-color: #343a40;">
            <h1 class="text-center mb-4 text-white">Editar IMC</h1>

            <?php if (session()->getFlashdata('error')): ?>
                <div class="alert alert-danger">
                    <?= session()->getFlashdata('error') ?>
                </div>
            <?php endif; ?>

            <form action="<?= site_url('imc/update/' . $imc['id']) ?>" method="post" class="d-flex flex-column align-items-center">
                <div class="mb-3 w-100">
                    <label for="alumno" class="form-label text-white">Alumno</label>
                    <select id="alumno" name="alumno" class="form-select" required>
                        <option value="">Seleccionar Alumno</option>
                        <?php foreach ($alumnos as $alumno): ?>
                            <option value="<?= esc($alumno['id']) ?>" <?= $alumno['id'] == $imc['alumno'] ? 'selected' : '' ?> readonly>
                                <?= esc($alumno['nombre']) ?> <?= esc($alumno['apellido']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="mb-3 w-100">
                    <label for="peso" class="form-label text-white">Peso (kg)</label>
                    <input type="number" class="form-control" id="peso" name="peso" value="<?= esc($imc['peso']) ?>" required>
                </div>

                <div class="mb-3 w-100">
                    <label for="altura" class="form-label text-white">Altura (cm)</label>
                    <input type="number" step="0.01" class="form-control" id="altura" name="altura" value="<?= esc($imc['altura']) ?>" required>
                </div>

                <div class="mb-3 w-100">
                    <label for="calculo" class="form-label text-white">IMC</label>
                    <input type="text" class="form-control" id="calculo" name="calculo" value="<?= esc($imc['calculo']) ?>" readonly>
                </div>

                <div class="mb-3 w-100">
                    <label for="fecha_calculo" class="form-label text-white">Fecha Cálculo</label>
                    <input type="text" class="form-control" id="fecha_calculo" name="fecha_calculo" value="<?= esc($imc['fecha_calculo']) ?>" readonly>
                </div>



                <div class="d-flex justify-content-between w-100">
                    <button type="submit" class="btn btn-primary">Guardar cambios</button>
                    <a href="<?= site_url('imc') ?>" class="btn btn-secondary">Cancelar</a>
                </div>
            </form>
        </div>
    </div>

    <footer style="background-color: black; color: white; font-weight: bold; text-align: center; padding: 10px; margin-top: 20px;">
        Desarrollado por Facundo Simeoni y Federico Moran.
    </footer>
</body>

</html>