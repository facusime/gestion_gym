<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de IMC</title>
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <!-- Js Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <!-- Estilos propios -->
    <link rel="stylesheet" href="<?= base_url('/public/css/styles.css') ?>">
</head>

<body>
    <div class="container mt-5">
        <div class="d-flex justify-content-between flex-wrap mb-3">
            <a href="<?= site_url('/menu') ?>" class="btn btn-secondary mb-2">Volver al Menú</a>
            <a href="<?= site_url('imc/create') ?>" class="btn btn-secondary mb-2">Agregar nuevo registro</a>
            <a href="<?= base_url('public/imagenes/imc.png') ?>" class="btn btn-secondary mb-2">Ver rangos de IMC</a>

        </div>

        <div class="card p-4">
            <h1 class="text-center mb-4">Lista de IMC</h1>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">Alumno</th>
                            <th scope="col">Peso</th>
                            <th scope="col">Altura</th>
                            <th scope="col">Cálculo</th>
                            <th scope="col">Fecha de Cálculo</th>
                            <th scope="col">Fecha de Modificación</th>
                            <th scope="col">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($imc as $registro) : ?>
                            <tr>
                                <td><?= esc($registro['alumno_nombre'] . ' ' . $registro['alumno_apellido']); ?></td>
                                <td><?= $registro['peso']; ?></td>
                                <td><?= $registro['altura']; ?></td>
                                <td><?= $registro['calculo']; ?></td>
                                <td><?= date('d-m-Y', strtotime($registro['fecha_calculo'])); ?></td>
                                <td><?= !empty($registro['fecha_modificacion']) ? date('d-m-Y', strtotime($registro['fecha_modificacion'])) : ''; ?></td>
                                <td>
                                    <a href="<?= site_url('imc/edit/' . $registro['id']) ?>" class="btn btn-primary btn-sm mb-1">Editar</a>
                                    <a href="<?= site_url('imc/delete/' . $registro['id']) ?>" class="btn btn-danger btn-sm mb-1" onclick="return confirm('¿Seguro que desea eliminar?')">Eliminar</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <footer class="mt-5 text-center bg-dark text-white fw-bold py-3">
            Desarrollado por Facundo Simeoni y Federico Moran
        </footer>
    </div>
</body>

</html>