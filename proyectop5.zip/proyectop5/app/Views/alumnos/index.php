<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menú</title>
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <!-- Js Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <!-- Estilos propios -->
    <link rel="stylesheet" href="<?= base_url('/public/css/styles.css') ?>">
</head>

<body>
    <div class="container mt-5">
        <div class="d-flex justify-content-between flex-wrap mb-3">
            <a href="<?= site_url('/menu') ?>" class="btn btn-secondary mb-2">Volver al Menú</a>
            <a href="<?= site_url('alumnos/create') ?>" class="btn btn-secondary mb-2">Agregar alumno</a>
        </div>
        <div class="card p-4">
            <h1 class="text-center mb-4">Lista de Alumnos</h1>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">Nombre</th>
                            <th scope="col">Apellido</th>
                            <th scope="col">Correo</th>
                            <th scope="col">Fecha de Registro</th>
                            <th scope="col">Tipo de actividad</th>
                            <th scope="col">Observaciones</th>
                            <th scope="col">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($alumnos as $alumno) : ?>
                            <tr>
                                <td><?= $alumno['nombre']; ?></td>
                                <td><?= $alumno['apellido']; ?></td>
                                <td><?= $alumno['correo']; ?></td>
                                <td><?= $alumno['fecha_registro']; ?></td>
                                <td><?= esc($alumno['actividad_nombre']); ?></td>
                                <td><?= $alumno['observaciones']; ?></td>
                                <td>
                                    <a href="<?= site_url('alumnos/edit/' . $alumno['id']) ?>" class="btn btn-primary btn-sm mb-1">Editar</a>
                                    <a href="<?= site_url('alumnos/delete/' . $alumno['id']) ?>" class="btn btn-danger btn-sm mb-1" onclick="return confirm('¿Seguro que desea eliminar?')">Eliminar</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <footer class="mt-5 text-center bg-dark text-white fw-bold py-3">
            Desarrollado por Facundo Simeoni y Federico Moran.
        </footer>
    </div>
</body>

</html>