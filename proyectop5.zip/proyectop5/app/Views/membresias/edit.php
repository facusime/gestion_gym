<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Membresía</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="<?= base_url('/public/css/menu.css') ?>">
</head>

<body>
    <div class="container mt-5 d-flex justify-content-center">
        <div class="card p-4" style="background-color: #343a40;">
            <h1 class="text-center mb-4 text-white">Editar Membresía</h1>

            <?php if (isset($validation)): ?>
                <div class="alert alert-danger">
                    <?= $validation->listErrors() ?>
                </div>
            <?php endif; ?>

            <form action="<?= site_url('membresias/update/' . $membresia['id']) ?>" method="POST" class="d-flex flex-column align-items-center">
                <?= csrf_field() ?>

                <div class="mb-3 w-100">
                    <label for="tipo_actividad" class="form-label text-white">Tipo de Actividad</label>
                    <select name="tipo_actividad" id="tipo_actividad" class="form-select" required>
                        <option value="0">Elija Actividad</option>
                        <?php foreach ($tipo_actividades as $tipo): ?>
                            <option value="<?= esc($tipo['id']) ?>" <?= ($membresia['tipo_actividad'] == $tipo['id']) ? 'selected' : '' ?>>
                                <?= esc($tipo['nombre']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="mb-3 w-100">
                    <label for="alumno" class="form-label text-white">Alumno (DNI)</label>
                    <select name="alumno" id="alumno" class="form-select" required>
                        <option value="0">Elija Alumno</option>
                        <?php foreach ($alumnos as $alumno): ?>
                            <option value="<?= esc($alumno['id']) ?>" <?= ($membresia['alumno'] == $alumno['id']) ? 'selected' : '' ?>>
                                <?= esc($alumno['dni']) ?> - <?= esc($alumno['nombre']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="mb-3 w-100">
                    <label for="precio" class="form-label text-white">Precio</label>
                    <input type="number" name="precio" id="precio" class="form-control" value="<?= esc($membresia['precio']) ?>" required>
                </div>

                <div class="mb-3 w-100">
                    <label class="form-label text-white">Clases</label>
                    <div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="clases" id="pase_libre" value="Pase Libre" <?= ($membresia['clases'] == 'Pase Libre') ? 'checked' : '' ?> required>
                            <label class="form-check-label text-white" for="pase_libre">Pase Libre</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="clases" id="doce" value="12" <?= ($membresia['clases'] == '12') ? 'checked' : '' ?> required>
                            <label class="form-check-label text-white" for="doce">12</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="clases" id="ocho" value="8" <?= ($membresia['clases'] == '8') ? 'checked' : '' ?> required>
                            <label class="form-check-label text-white" for="ocho">8</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="clases" id="cuatro" value="4" <?= ($membresia['clases'] == '4') ? 'checked' : '' ?> required>
                            <label class="form-check-label text-white" for="cuatro">4</label>
                        </div>
                    </div>
                </div>

                <div class="mb-3 w-100">
                    <label for="fecha_alta" class="form-label text-white">Fecha Alta</label>
                    <input type="date" name="fecha_alta" id="fecha_alta" class="form-control" value="<?= esc($membresia['fecha_alta']) ?>" required>
                </div>

                <div class="mb-3 w-100">
                    <label for="fecha_baja" class="form-label text-white">Fecha Baja</label>
                    <input type="date" name="fecha_baja" id="fecha_baja" class="form-control" value="<?= esc($membresia['fecha_baja']) ?>" required>
                </div>

                <div class="mb-3 w-100">
                    <label for="turnos" class="form-label text-white">Turno</label>
                    <select name="turnos" id="turnos" class="form-select" required>
                        <option value="0">Elija Turno</option>
                        <?php foreach ($turnos as $turno): ?>
                            <option value="<?= esc($turno['id']) ?>" <?= ($membresia['turnos'] == $turno['id']) ? 'selected' : '' ?>>
                                <?= esc($turno['horario']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="mb-3 w-100">
                    <label class="form-label text-white">Estado</label>
                    <div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="estado" id="activo" value="Activo" <?= ($membresia['estado'] == 'Activo') ? 'checked' : '' ?> required>
                            <label class="form-check-label text-white" for="activo">Activo</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="estado" id="inactivo" value="Inactivo" <?= ($membresia['estado'] == 'Inactivo') ? 'checked' : '' ?> required>
                            <label class="form-check-label text-white" for="inactivo">Inactivo</label>
                        </div>
                    </div>
                </div>

                <div class="d-flex justify-content-between w-100">
                    <button type="submit" class="btn btn-primary">Guardar cambios</button>
                    <a href="<?= site_url('membresias') ?>" class="btn btn-secondary">Cancelar</a>
                </div>
            </form>
        </div>
    </div>

    <footer style="background-color: black; color: white; font-weight: bold; text-align: center;" class="mt-5">
        Desarrollado por Facundo Simeoni y Federico Moran.
    </footer>
</body>

</html>